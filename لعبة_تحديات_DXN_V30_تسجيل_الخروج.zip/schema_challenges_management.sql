-- إدارة التحديات للقائد - إضافة/تعديل/نقاط/تجميد/حذف منطقي
-- يطبّق مرة واحدة على قاعدة DXN Tahadi الحالية.

alter table public.challenges
  add column if not exists deleted_at timestamptz;

create or replace function public.create_challenge(
  p_token uuid,
  p_type text,
  p_title text,
  p_description text,
  p_stars integer,
  p_repeat_rule text
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare x uuid;
begin
  if public.app_current_role(p_token) <> 'leader' then
    raise exception 'صلاحية القائد فقط';
  end if;
  if trim(coalesce(p_title,'')) = '' then raise exception 'اسم التحدي مطلوب'; end if;
  if coalesce(p_stars,0) < 0 then raise exception 'عدد النجوم غير صحيح'; end if;
  insert into public.challenges(type,title,description,stars,repeat_rule,active,deleted_at)
  values(trim(coalesce(p_type,'عام')),trim(p_title),trim(coalesce(p_description,'')),p_stars,trim(coalesce(p_repeat_rule,'مرة واحدة')),true,null)
  returning id into x;
  return x;
end $$;

create or replace function public.update_challenge(
  p_token uuid,
  p_challenge uuid,
  p_type text,
  p_title text,
  p_description text,
  p_stars integer,
  p_repeat_rule text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if public.app_current_role(p_token) <> 'leader' then
    raise exception 'صلاحية القائد فقط';
  end if;
  if trim(coalesce(p_title,'')) = '' then raise exception 'اسم التحدي مطلوب'; end if;
  if coalesce(p_stars,0) < 0 then raise exception 'عدد النجوم غير صحيح'; end if;
  update public.challenges
  set type=trim(coalesce(p_type,'عام')),
      title=trim(p_title),
      description=trim(coalesce(p_description,'')),
      stars=p_stars,
      repeat_rule=trim(coalesce(p_repeat_rule,'مرة واحدة'))
  where id=p_challenge and deleted_at is null;
  if not found then raise exception 'التحدي غير موجود أو محذوف'; end if;
end $$;

create or replace function public.set_challenge_stars(
  p_token uuid,
  p_challenge uuid,
  p_stars integer
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if public.app_current_role(p_token) <> 'leader' then raise exception 'صلاحية القائد فقط'; end if;
  if coalesce(p_stars,0) < 0 then raise exception 'عدد النجوم غير صحيح'; end if;
  update public.challenges set stars=p_stars where id=p_challenge and deleted_at is null;
  if not found then raise exception 'التحدي غير موجود أو محذوف'; end if;
end $$;

create or replace function public.toggle_challenge_freeze(
  p_token uuid,
  p_challenge uuid,
  p_frozen boolean
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if public.app_current_role(p_token) <> 'leader' then raise exception 'صلاحية القائد فقط'; end if;
  update public.challenges set active=not p_frozen where id=p_challenge and deleted_at is null;
  if not found then raise exception 'التحدي غير موجود أو محذوف'; end if;
end $$;

create or replace function public.delete_challenge(
  p_token uuid,
  p_challenge uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if public.app_current_role(p_token) <> 'leader' then raise exception 'صلاحية القائد فقط'; end if;
  update public.challenges set active=false, deleted_at=now() where id=p_challenge and deleted_at is null;
  if not found then raise exception 'التحدي غير موجود أو محذوف'; end if;
end $$;

create or replace function public.bootstrap(p_token uuid)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare r text; uid uuid; memberid uuid; mk text:=to_char(current_date,'YYYY-MM');
begin
  r:=public.app_current_role(p_token);
  uid:=public.current_user_id(p_token);
  if r is null then raise exception 'انتهت الجلسة'; end if;
  if r='member' then select member_id into memberid from public.app_users where id=uid; end if;
  return json_build_object(
   'role',r,
   'teams',(select coalesce(json_agg(x order by x.name),'[]'::json) from public.team_stats x),
   'members',(select coalesce(json_agg(x order by x.stars desc,x.name),'[]'::json) from public.member_stats x where r='leader' or x.id=memberid),
   'challenges',(select coalesce(json_agg(c order by c.type,c.created_at),'[]'::json) from public.challenges c where (c.active and c.deleted_at is null) or (r='leader' and c.deleted_at is null)),
   'questions',(select coalesce(json_agg(q order by q.question_no),'[]'::json) from public.monthly_questions q where q.month_key=mk and q.active),
   'my_answers',(select coalesce(json_agg(a),'[]'::json) from public.question_answers a join public.monthly_questions q on q.id=a.question_id where q.month_key=mk and (r='leader' or a.member_id=memberid)),
   'my_submissions',(select coalesce(json_agg(s),'[]'::json) from public.challenge_submissions s where r='leader' or s.member_id=memberid),
   'monthly',(select coalesce(json_agg(mt),'[]'::json) from public.monthly_targets mt where r='leader' or mt.member_id=memberid)
  );
end $$;

grant execute on function public.create_challenge(uuid,text,text,text,integer,text) to anon, authenticated;
grant execute on function public.update_challenge(uuid,uuid,text,text,text,integer,text) to anon, authenticated;
grant execute on function public.set_challenge_stars(uuid,uuid,integer) to anon, authenticated;
grant execute on function public.toggle_challenge_freeze(uuid,uuid,boolean) to anon, authenticated;
grant execute on function public.delete_challenge(uuid,uuid) to anon, authenticated;
grant execute on function public.bootstrap(uuid) to anon, authenticated;
